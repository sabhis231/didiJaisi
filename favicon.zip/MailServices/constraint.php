<?php

// HOST details
$hostName="mail.didijaisi.com";
$SMTPSecure="tsl";
$port=587;
$hostDisplayName="DidiJaisi";
$defaultSubject="Subscription";


// Declaring User Auth Variable


$userName = "subscribe@didijaisi.com";
$userPassword = 'QqXvu~52^4uC';


?>